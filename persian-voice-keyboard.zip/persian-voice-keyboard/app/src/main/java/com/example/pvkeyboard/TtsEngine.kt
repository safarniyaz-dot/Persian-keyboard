package com.example.pvkeyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.getOfflineTtsConfig
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline Persian text-to-speech: Piper voice (VITS, fa_IR "amir") running on sherpa-onnx.
 * Files are bundled by scripts/download_tts.sh:
 *   assets/tts-fa/fa_IR-amir-medium.onnx, assets/tts-fa/tokens.txt, assets/tts-fa/espeak-ng-data/...
 * Speech is generated sentence by sentence and streamed to an AudioTrack, so it starts quickly.
 */
class TtsEngine(context: Context, private val cb: Callbacks) {

    interface Callbacks {
        fun onStatus(msg: String)
        /** Called when speaking ended or was stopped. */
        fun onDone()
        fun onError(msg: String)
    }

    companion object {
        const val ASSET_DIR = "tts-fa"
        const val MODEL = "fa_IR-amir-medium.onnx"
        private const val TAG = "PvkTts"
        private const val MAX_CHARS = 8000
        private const val DATA_VERSION = "1"

        private val harakat = Regex("[ً-ٰٟ]")
        private val spaces = Regex("\\s+")

        /** Normalizes Persian text so the phonemizer reads it well. */
        fun clean(s: String): String {
            val sb = StringBuilder(s.length)
            for (ch in s) {
                when (ch) {
                    'ي' -> sb.append('ی')
                    'ك' -> sb.append('ک')
                    '‌' -> sb.append(' ')
                    'ـ' -> {}
                    '،' -> sb.append(',')
                    '؛' -> sb.append(';')
                    '؟' -> sb.append('?')
                    in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                    in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                    else -> sb.append(ch)
                }
            }
            var t = sb.toString().replace(harakat, "").replace(spaces, " ").trim()
            if (t.length > MAX_CHARS) t = t.substring(0, MAX_CHARS)
            return t
        }
    }

    private val app: Context = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile
    private var tts: OfflineTts? = null

    @Volatile
    private var current: AtomicBoolean? = null

    @Volatile
    var speaking = false
        private set

    /** True when the voice files are inside this APK. */
    val bundled: Boolean by lazy {
        try {
            app.assets.list(ASSET_DIR)?.contains(MODEL) == true
        } catch (e: IOException) {
            false
        }
    }

    fun speak(raw: String, speed: Float) {
        val text = clean(raw)
        if (text.isBlank()) {
            cb.onError("متنی برای خواندن نیست")
            return
        }
        stop()
        val cancel = AtomicBoolean(false)
        current = cancel
        speaking = true
        executor.execute { run(text, speed.coerceIn(0.5f, 2.0f), cancel) }
    }

    fun stop() {
        current?.set(true)
    }

    fun release() {
        stop()
        executor.execute {
            try {
                tts?.release()
            } catch (e: Throwable) {
                // ignored
            }
            tts = null
        }
        executor.shutdown()
    }

    // ---------------------------------------------------------------- worker

    private fun post(block: () -> Unit) {
        main.post(block)
    }

    private fun run(text: String, speed: Float, cancel: AtomicBoolean) {
        var track: AudioTrack? = null
        try {
            val engine = ensureLoaded(cancel)
            if (cancel.get()) return
            post { cb.onStatus("در حال خواندن…") }

            val sr = engine.sampleRate()
            val minBuf = AudioTrack.getMinBufferSize(
                sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT
            )
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sr)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, sr * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            t.play()

            var frames = 0L
            engine.generateWithCallback(text = text, sid = 0, speed = speed) { samples ->
                var off = 0
                while (off < samples.size && !cancel.get()) {
                    val n = t.write(samples, off, samples.size - off, AudioTrack.WRITE_BLOCKING)
                    if (n <= 0) break
                    off += n
                }
                frames += off
                if (cancel.get()) 0 else 1
            }

            if (!cancel.get()) {
                // let the buffered audio finish playing
                t.stop()
                val deadline = SystemClock.uptimeMillis() + frames * 1000L / sr + 3000L
                while (!cancel.get() && t.playbackHeadPosition < frames &&
                    SystemClock.uptimeMillis() < deadline
                ) {
                    Thread.sleep(40)
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "TTS failed", e)
            val msg = when (e) {
                is UnsatisfiedLinkError -> "کتابخانهٔ خواندن آفلاین داخل این APK نیست"
                else -> "خطا در خواندن متن: ${e.message ?: e.javaClass.simpleName}"
            }
            if (!cancel.get()) post { cb.onError(msg) }
        } finally {
            try {
                if (cancel.get()) {
                    track?.pause()
                    track?.flush()
                }
                track?.release()
            } catch (e: Throwable) {
                // ignored
            }
            if (current === cancel) {
                current = null
                speaking = false
                post { cb.onDone() }
            }
        }
    }

    @Synchronized
    private fun ensureLoaded(cancel: AtomicBoolean): OfflineTts {
        tts?.let { return it }
        post { cb.onStatus("در حال آماده‌سازی صدا (فقط بار اول، چند ثانیه)…") }
        val dataDir = prepareEspeakData()
        if (cancel.get()) throw IllegalStateException("cancelled")
        val config = getOfflineTtsConfig(
            modelDir = ASSET_DIR,
            modelName = MODEL,
            acousticModelName = "",
            vocoder = "",
            voices = "",
            lexicon = "",
            dataDir = dataDir,
            dictDir = "",
            ruleFsts = "",
            ruleFars = "",
            numThreads = 2
        )
        val engine = OfflineTts(assetManager = app.assets, config = config)
        tts = engine
        return engine
    }

    /** espeak-ng needs real files, so its data folder is copied from assets once. */
    private fun prepareEspeakData(): String {
        val base = File(app.filesDir, ASSET_DIR)
        val data = File(base, "espeak-ng-data")
        val marker = File(base, ".copied-$DATA_VERSION")
        if (!marker.exists()) {
            data.deleteRecursively()
            base.mkdirs()
            copyAssetDir("$ASSET_DIR/espeak-ng-data", data)
            marker.writeText("ok")
        }
        return data.absolutePath
    }

    private fun copyAssetDir(path: String, dest: File) {
        val names = app.assets.list(path) ?: emptyArray()
        if (names.isEmpty()) {
            try {
                dest.parentFile?.mkdirs()
                app.assets.open(path).use { input ->
                    FileOutputStream(dest).use { out -> input.copyTo(out) }
                }
            } catch (e: IOException) {
                // an empty directory, nothing to copy
            }
        } else {
            dest.mkdirs()
            for (n in names) copyAssetDir("$path/$n", File(dest, n))
        }
    }
}
