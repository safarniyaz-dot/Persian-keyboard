package com.example.pvkeyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Simple setup screen: enable the keyboard, pick it, allow the microphone. */
class MainActivity : Activity() {

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("pvk", MODE_PRIVATE)

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.setPadding(dp(20), dp(28), dp(20), dp(20))
        scroll.addView(col)

        fun label(t: String, sp: Float, bold: Boolean = false): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.setPadding(0, dp(10), 0, dp(4))
            return tv
        }

        fun button(t: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { onClick() }
            return b
        }

        col.addView(label("کیبورد فارسی با تایپ صوتی", 24f, bold = true))
        col.addView(label("فارسی و انگلیسی + دیکته به فارسی با دکمهٔ 🎤 بالای کیبورد", 14f))

        col.addView(label("۱) فعال‌سازی", 16f, bold = true))
        col.addView(button("باز کردن تنظیمات کیبورد‌ها") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })

        col.addView(label("۲) انتخاب به‌عنوان کیبورد فعلی", 16f, bold = true))
        col.addView(button("انتخاب کیبورد") {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })

        col.addView(label("۳) اجازهٔ میکروفون (برای تایپ صوتی)", 16f, bold = true))
        col.addView(button("دادن اجازهٔ میکروفون") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })

        val bundled = try {
            (assets.list("model-fa")?.size ?: 0) > 0
        } catch (e: java.io.IOException) {
            false
        }
        col.addView(
            label(
                if (bundled) "✅ مدل آفلاین فارسی داخل برنامه است (بدون اینترنت کار می‌کند)"
                else "⚠️ این APK بدون مدل آفلاین ساخته شده؛ از GitHub Actions بسازید",
                13f
            )
        )

        val sw = Switch(this)
        sw.text = "تشخیص گفتار آفلاین فارسی (موتور داخلی). اگر خاموش باشد، از Google استفاده می‌شود."
        sw.isChecked = prefs.getBoolean("vosk", true)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("vosk", checked).apply()
        }
        sw.setPadding(0, dp(14), 0, dp(14))
        col.addView(sw)

        col.addView(label("امتحان کنید", 16f, bold = true))
        val test = EditText(this)
        test.hint = "اینجا را لمس کنید و تایپ کنید…"
        test.minLines = 3
        test.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        col.addView(test)

        setContentView(scroll)
    }
}
