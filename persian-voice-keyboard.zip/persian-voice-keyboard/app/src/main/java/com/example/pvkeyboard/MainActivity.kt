package com.example.pvkeyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged

/** Setup + settings screen: enable the keyboard, key feedback, voice commands help, test field. */
class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var fb: KeyFeedback
    private var ttsEngine: TtsEngine? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun label(t: String, sp: Float, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setPadding(0, dp(10), 0, dp(4))
        return tv
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { onClick() }
        return b
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.cornerRadius = dp(12).toFloat()
        bg.setColor(0xFFF1F3F8.toInt())
        c.background = bg
        c.setPadding(dp(14), dp(8), dp(14), dp(12))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(8), 0, dp(8))
        c.layoutParams = lp
        return c
    }

    private fun switchRow(text: String, key: String, def: Boolean): Switch {
        val sw = Switch(this)
        sw.text = text
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            fb.load(prefs)
            if (checked) fb.tap()
        }
        sw.setPadding(0, dp(10), 0, dp(6))
        return sw
    }

    /** A slider that stores an Int pref and gives a sample of the feedback when released. */
    private fun seekRow(
        title: String,
        unit: String,
        min: Int,
        max: Int,
        key: String,
        def: Int,
        preview: Boolean = true
    ): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val cur = prefs.getInt(key, def).coerceIn(min, max)
        val tv = label("$title: $cur $unit", 13f)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                tv.text = "$title: ${p + min} $unit"
            }

            override fun onStartTrackingTouch(s: SeekBar) {}

            override fun onStopTrackingTouch(s: SeekBar) {
                prefs.edit().putInt(key, s.progress + min).apply()
                fb.load(prefs)
                if (preview) fb.tap()
            }
        })
        box.addView(tv)
        box.addView(sb)
        return box
    }

    private fun cmdField(title: String, key: String, def: String): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(label(title, 13f))
        val et = EditText(this)
        et.setSingleLine(true)
        et.setText(prefs.getString(key, def) ?: def)
        et.doAfterTextChanged { prefs.edit().putString(key, it?.toString() ?: "").apply() }
        box.addView(et)
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pvk", MODE_PRIVATE)
        fb = KeyFeedback(this)
        fb.load(prefs)

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.setPadding(dp(20), dp(28), dp(20), dp(28))
        scroll.addView(col)

        col.addView(label("کیبورد فارسی با تایپ صوتی", 24f, bold = true))
        col.addView(label("فارسی و انگلیسی + دیکته به فارسی با دکمهٔ 🎤 بالای کیبورد", 14f))

        // ---- setup
        col.addView(label("۱) فعال‌سازی", 16f, bold = true))
        col.addView(button("باز کردن تنظیمات کیبورد‌ها") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })

        col.addView(label("۲) انتخاب به‌عنوان کیبورد فعلی", 16f, bold = true))
        col.addView(button("انتخاب کیبورد") {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })

        col.addView(label("۳) اجازهٔ میکروفون (برای تایپ صوتی)", 16f, bold = true))
        col.addView(button("دادن اجازهٔ میکروفون") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })

        // ---- key feedback
        col.addView(label("لرزش و صدای کلیدها", 18f, bold = true))
        val fbCard = card()
        fbCard.addView(switchRow("لرزش هنگام زدن کلیدها", "vib_on", true))
        fbCard.addView(seekRow("مدت لرزش", "میلی‌ثانیه", 5, 60, "vib_ms", 20))
        fbCard.addView(switchRow("صدای کلیک هنگام زدن کلیدها", "snd_on", false))
        fbCard.addView(seekRow("بلندی صدا", "٪", 0, 100, "snd_vol", 60))
        fbCard.addView(
            label(
                "صدا با میزان صدای سیستم گوشی هم تنظیم می‌شود؛ اگر گوشی روی بی‌صدا یا صدای سیستم صفر باشد، شنیده نمی‌شود.",
                12f
            )
        )
        col.addView(fbCard)

        // ---- offline engine
        col.addView(label("تایپ صوتی", 18f, bold = true))
        val bundled = try {
            (assets.list("model-fa")?.size ?: 0) > 0
        } catch (e: java.io.IOException) {
            false
        }
        col.addView(
            label(
                if (bundled) "✅ مدل آفلاین فارسی داخل برنامه است (بدون اینترنت کار می‌کند)"
                else "⚠️ این APK بدون مدل آفلاین ساخته شده؛ از GitHub Actions بسازید",
                13f
            )
        )
        val sw = Switch(this)
        sw.text = "تشخیص گفتار آفلاین فارسی (موتور داخلی). اگر خاموش باشد، از Google استفاده می‌شود."
        sw.isChecked = prefs.getBoolean("vosk", true)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("vosk", checked).apply()
        }
        sw.setPadding(0, dp(10), 0, dp(10))
        col.addView(sw)

        // ---- voice commands help
        col.addView(label("راهنمای دستورهای صوتی (فارسی)", 18f, bold = true))
        val help = card()
        help.addView(
            label(
                "هنگام تایپ صوتی می‌توانید این کلمه‌ها را بگویید:\n\n" +
                    "• «${VoiceCommands.DEF_DEL}» ← آخرین کلمهٔ تایپ‌شده پاک می‌شود. هر بار که «${VoiceCommands.DEF_DEL}» را تکرار کنید، " +
                    "یک کلمهٔ دیگر پاک می‌شود (مثلاً «${VoiceCommands.DEF_DEL} ${VoiceCommands.DEF_DEL}» یعنی دو کلمه). " +
                    "اگر آخر متن ویرگول یا نقطه باشد، اول همان پاک می‌شود.\n\n" +
                    "• «${VoiceCommands.DEF_COMMA}» ← ویرگول (،) گذاشته می‌شود.\n\n" +
                    "• «${VoiceCommands.DEF_PERIOD}» ← نقطه (.) گذاشته می‌شود.\n\n" +
                    "مثال: «سلام ${VoiceCommands.DEF_COMMA} حال شما چطوره ${VoiceCommands.DEF_PERIOD}» ← «سلام، حال شما چطوره.»",
                14f
            )
        )
        help.addView(
            label(
                "نکته‌ها:\n" +
                    "• دستور را واضح و جدا از جمله بگویید؛ در حالت آفلاین بعد از یک مکث کوتاه اجرا می‌شود.\n" +
                    "• دستورها فقط در حالت فارسی کار می‌کنند.\n" +
                    "• مدل آفلاین فقط کلمه‌های خودش را می‌شناسد. اگر یکی از دستورها را درست تشخیص نداد، " +
                    "پایین کلمهٔ دیگری برایش بگذارید (چند کلمه را با ویرگول جدا کنید، مثلاً «تش، تیش»).",
                13f
            )
        )
        col.addView(help)

        col.addView(label("کلمه‌های دستورها (قابل تغییر)", 15f, bold = true))
        col.addView(cmdField("پاک کردن آخرین کلمه", "cmd_del", VoiceCommands.DEF_DEL))
        col.addView(cmdField("ویرگول", "cmd_comma", VoiceCommands.DEF_COMMA))
        col.addView(cmdField("نقطه", "cmd_period", VoiceCommands.DEF_PERIOD))

        // ---- long-press help
        col.addView(label("نگه‌داشتن کلیدها", 18f, bold = true))
        val lp = card()
        lp.addView(
            label(
                "روی بعضی کلیدها یک حرف کوچک نوشته شده؛ کلید را نگه دارید تا حروف جایگزین باز شود، " +
                    "انگشت را روی حرف دلخواه ببرید و رها کنید.\n\n" +
                    "• ا ← آ ء أ إ\n• ز ← ژ\n• و ← ؤ\n• ی ← ئ ي\n• ه ← ة ۀ\n• ک ← ك\n" +
                    "• ، و . ← علامت‌های دیگر (؛ ؟ ! …)\n• انگلیسی: a ← à á â ä … و e, i, o, u, c, n, s, y",
                13f
            )
        )
        col.addView(lp)

        // ---- test field
        col.addView(label("امتحان کنید", 16f, bold = true))
        val test = EditText(this)
        test.hint = "اینجا را لمس کنید و تایپ کنید…"
        test.minLines = 3
        test.gravity = Gravity.TOP or Gravity.START
        col.addView(test)

        // ---- offline text to speech
        col.addView(label("خواندن متن (آفلاین)", 18f, bold = true))
        val ttsCard = card()
        val ttsBundled = try {
            assets.list(TtsEngine.ASSET_DIR)?.contains(TtsEngine.MODEL) == true
        } catch (e: java.io.IOException) {
            false
        }
        ttsCard.addView(
            label(
                if (ttsBundled) "✅ صدای فارسی آفلاین داخل برنامه است (بدون اینترنت کار می‌کند)"
                else "⚠️ این APK بدون صدای آفلاین ساخته شده؛ از GitHub Actions بسازید",
                13f
            )
        )
        ttsCard.addView(
            label(
                "دکمهٔ 🔊 کنار 🎤 بالای کیبورد، متن انتخاب‌شده را می‌خواند. اگر چیزی انتخاب نشده باشد، " +
                    "کل متن کادر را می‌خواند. برای توقف، دوباره آن را بزنید (⏹).",
                13f
            )
        )
        ttsCard.addView(seekRow("سرعت خواندن", "٪", 50, 200, "tts_speed", 100, preview = false))
        val ttsStatus = label("", 12f)
        ttsCard.addView(ttsStatus)
        ttsCard.addView(button("خواندن متن کادر امتحان") {
            val eng = ttsEngine ?: TtsEngine(this, object : TtsEngine.Callbacks {
                override fun onStatus(msg: String) {
                    ttsStatus.text = msg
                }

                override fun onDone() {
                    ttsStatus.text = ""
                }

                override fun onError(msg: String) {
                    ttsStatus.text = msg
                }
            }).also { ttsEngine = it }
            if (eng.speaking) {
                eng.stop()
            } else if (!ttsBundled) {
                ttsStatus.text = "صدای آفلاین داخل این APK نیست"
            } else {
                val t = test.text.toString().ifBlank { "سلام، این یک آزمایش خواندن متن فارسی است." }
                eng.speak(t, prefs.getInt("tts_speed", 100) / 100f)
            }
        })
        col.addView(ttsCard)

        setContentView(scroll)
    }

    override fun onDestroy() {
        ttsEngine?.release()
        fb.release()
        super.onDestroy()
    }
}
