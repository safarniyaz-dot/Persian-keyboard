package com.example.pvkeyboard

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class KeyboardService : InputMethodService() {

    private class Palette(
        val bg: Int,
        val key: Int,
        val keyPressed: Int,
        val func: Int,
        val text: Int,
        val subText: Int,
        val accent: Int,
        val accentPressed: Int,
        val accentText: Int
    )

    companion object {
        private const val KIND_NORMAL = 0
        private const val KIND_FUNC = 1
        private const val KIND_ACCENT = 2
        private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val MAX_SILENT_RESTARTS = 4
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var pal: Palette

    // keyboard state
    private var lang = "fa"
    private var shift = 0 // 0 off, 1 one-shot, 2 caps lock
    private var symbols = false
    private var forceLatinDigits = false
    private var lastShiftTap = 0L

    // views
    private var root: LinearLayout? = null
    private var keysContainer: LinearLayout? = null
    private var statusView: TextView? = null
    private var micView: TextView? = null
    private var repeatRunnable: Runnable? = null

    // voice state
    private var recognizer: SpeechRecognizer? = null
    private var voiceActive = false
    private var awaitingFinal = false
    private var errorStreak = 0
    private var usingVosk = false
    private val vosk: VoskEngine by lazy { VoskEngine(this, voskCallbacks) }

    private val restartRunnable = Runnable { if (voiceActive) listenOnce() }
    private val finalizeRunnable = Runnable {
        if (awaitingFinal) {
            awaitingFinal = false
            if (usingVosk) vosk.cancel() else recognizer?.cancel()
            currentInputConnection?.finishComposingText()
            setStatus(defaultStatus())
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("pvk", MODE_PRIVATE)
        lang = prefs.getString("lang", "fa") ?: "fa"
        pal = buildPalette()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        r.setPadding(dp(3), dp(2), dp(3), dp(4))
        root = r
        rebuild()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        stopVoice()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        val numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
        symbols = numeric
        forceLatinDigits = numeric
        val caps = if (info != null) (currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0) else 0
        shift = if (lang == "en" && caps != 0) 1 else 0
        rebuild()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        stopVoice()
        super.onFinishInputView(finishingInput)
    }

    override fun onWindowHidden() {
        stopVoice()
        super.onWindowHidden()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        vosk.release()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- theme / helpers

    private fun buildPalette(): Palette {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return if (night) {
            Palette(
                bg = 0xFF1E1F22.toInt(), key = 0xFF3A3C41.toInt(), keyPressed = 0xFF5A5D65.toInt(),
                func = 0xFF2B2D31.toInt(), text = 0xFFEDEDED.toInt(), subText = 0xFFA9ACB3.toInt(),
                accent = 0xFF7FA6FF.toInt(), accentPressed = 0xFF5F86DF.toInt(), accentText = 0xFF0B1A3A.toInt()
            )
        } else {
            Palette(
                bg = 0xFFE9EAEE.toInt(), key = 0xFFFFFFFF.toInt(), keyPressed = 0xFFC9CCD3.toInt(),
                func = 0xFFD3D6DD.toInt(), text = 0xFF1B1B1F.toInt(), subText = 0xFF5B5E66.toInt(),
                accent = 0xFF3E6BFF.toInt(), accentPressed = 0xFF2A52D6.toInt(), accentText = 0xFFFFFFFF.toInt()
            )
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun displayLabel(k: String): String {
        if (k.length == 1) {
            val c = k[0]
            if (c in 'ً'..'ٟ' || c == 'ٰ') return "ـ" + k
        }
        return k
    }

    private fun defaultStatus(): String =
        if (lang == "fa") "برای تایپ صوتی، 🎤 را بزنید" else "Tap 🎤 for voice typing"

    private fun setStatus(msg: String) {
        statusView?.text = msg
    }

    // ---------------------------------------------------------------- UI building

    private fun rebuild() {
        val r = root ?: return
        pal = buildPalette()
        r.setBackgroundColor(pal.bg)
        r.removeAllViews()
        r.addView(buildToolbar())
        val kc = LinearLayout(this)
        kc.orientation = LinearLayout.VERTICAL
        keysContainer = kc
        r.addView(kc, LinearLayout.LayoutParams(MATCH, WRAP))
        renderKeys()
    }

    private fun buildToolbar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutParams = LinearLayout.LayoutParams(MATCH, dp(46))

        val gear = TextView(this)
        gear.text = "⚙"
        gear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        gear.setTextColor(pal.subText)
        gear.gravity = Gravity.CENTER
        gear.setOnClickListener { openSettings() }
        bar.addView(gear, LinearLayout.LayoutParams(dp(46), MATCH))

        val st = TextView(this)
        st.gravity = Gravity.CENTER
        st.setTextColor(pal.subText)
        st.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        st.maxLines = 1
        st.ellipsize = android.text.TextUtils.TruncateAt.END
        statusView = st
        bar.addView(st, LinearLayout.LayoutParams(0, MATCH, 1f))

        val mic = TextView(this)
        mic.gravity = Gravity.CENTER
        mic.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        mic.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            toggleVoice()
        }
        micView = mic
        val mlp = LinearLayout.LayoutParams(dp(60), dp(40))
        mlp.setMargins(dp(4), 0, dp(4), 0)
        bar.addView(mic, mlp)

        updateMic()
        setStatus(defaultStatus())
        return bar
    }

    private fun updateMic() {
        val m = micView ?: return
        val bg = GradientDrawable()
        bg.cornerRadius = dp(20).toFloat()
        bg.setColor(if (voiceActive) 0xFFE53935.toInt() else pal.key)
        m.background = bg
        m.text = "🎤"
        if (!voiceActive) {
            m.scaleX = 1f
            m.scaleY = 1f
        }
    }

    private fun newRow(heightDp: Int): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER
        r.layoutParams = LinearLayout.LayoutParams(MATCH, dp(heightDp))
        return r
    }

    private fun renderKeys() {
        val c = keysContainer ?: return
        c.removeAllViews()
        val fa = lang == "fa"

        // number row
        val nums = if (fa && !forceLatinDigits) Layouts.faNumbers else Layouts.enNumbers
        val numRow = newRow(40)
        for (n in nums) {
            numRow.addView(key(n, 1f, KIND_NORMAL, textSp = 17f) { typeText(n) })
        }
        c.addView(numRow)

        val letters: List<List<String>> = when {
            symbols -> Layouts.symbols
            fa && shift != 0 -> Layouts.faShift
            fa -> Layouts.fa
            else -> Layouts.en
        }

        for ((i, rowKeys) in letters.withIndex()) {
            val row = newRow(48)
            if (i == 2 && !symbols) row.addView(shiftKey())
            for (k in rowKeys) {
                val label = if (!fa && !symbols && shift != 0) k.uppercase() else k
                row.addView(key(label, 1f, KIND_NORMAL) { typeLetter(label) })
            }
            if (i == 2) row.addView(backspaceKey())
            c.addView(row)
        }

        c.addView(bottomRow())
    }

    private fun shiftKey(): TextView {
        val kind = if (shift == 2) KIND_ACCENT else KIND_FUNC
        val label = when (shift) {
            2 -> "⇪"
            1 -> "⬆"
            else -> "⇧"
        }
        return key(label, 1.4f, kind) {
            val now = SystemClock.uptimeMillis()
            shift = when (shift) {
                0 -> 1
                1 -> if (now - lastShiftTap < 350) 2 else 0
                else -> 0
            }
            lastShiftTap = now
            handler.post { renderKeys() }
        }
    }

    private fun backspaceKey(): TextView =
        key("⌫", 1.4f, KIND_FUNC, repeat = true) { deleteBack() }

    private fun bottomRow(): LinearLayout {
        val fa = lang == "fa"
        val row = newRow(48)

        val symLabel = when {
            symbols -> if (fa) "الفبا" else "ABC"
            else -> if (fa) "؟۱۲۳" else "?123"
        }
        row.addView(key(symLabel, 1.5f, KIND_FUNC, textSp = 14f) {
            symbols = !symbols
            shift = 0
            handler.post { renderKeys() }
        })
        row.addView(key("🌐", 1.1f, KIND_FUNC, textSp = 18f) { switchLang() })

        val comma = if (fa) "،" else ","
        row.addView(key(comma, 1f, KIND_NORMAL) { typeText(comma) })

        row.addView(key(if (fa) "فارسی" else "English", 4f, KIND_NORMAL, textSp = 13f) { typeText(" ") })

        if (fa) {
            row.addView(key("نیم‌فاصله", 1.5f, KIND_FUNC, textSp = 11f) { typeText("‌") })
        }
        row.addView(key(".", 1f, KIND_NORMAL) { typeText(".") })
        row.addView(key("⏎", 1.5f, KIND_ACCENT) { pressEnter() })
        return row
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun key(
        label: String,
        weight: Float,
        kind: Int = KIND_NORMAL,
        repeat: Boolean = false,
        textSp: Float = 20f,
        action: () -> Unit
    ): TextView {
        val p = pal
        val bgColor = when (kind) {
            KIND_FUNC -> p.func
            KIND_ACCENT -> p.accent
            else -> p.key
        }
        val pressedColor = if (kind == KIND_ACCENT) p.accentPressed else p.keyPressed
        val fg = if (kind == KIND_ACCENT) p.accentText else p.text

        val shape = GradientDrawable()
        shape.cornerRadius = dp(8).toFloat()
        shape.setColor(bgColor)

        val tv = TextView(this)
        tv.text = displayLabel(label)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
        tv.setTextColor(fg)
        tv.gravity = Gravity.CENTER
        tv.background = shape
        tv.maxLines = 1

        val lp = LinearLayout.LayoutParams(0, MATCH, weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        tv.layoutParams = lp

        tv.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    shape.setColor(pressedColor)
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    action()
                    if (repeat) {
                        stopRepeat()
                        val r = object : Runnable {
                            override fun run() {
                                action()
                                handler.postDelayed(this, 50)
                            }
                        }
                        repeatRunnable = r
                        handler.postDelayed(r, 380)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    shape.setColor(bgColor)
                    stopRepeat()
                    true
                }
                else -> true
            }
        }
        return tv
    }

    private fun stopRepeat() {
        repeatRunnable?.let { handler.removeCallbacks(it) }
        repeatRunnable = null
    }

    // ---------------------------------------------------------------- typing actions

    private fun typeText(s: String) {
        if (voiceActive) stopVoice()
        currentInputConnection?.commitText(s, 1)
    }

    private fun typeLetter(s: String) {
        typeText(s)
        if (shift == 1) {
            shift = 0
            handler.post { renderKeys() }
        }
    }

    private fun deleteBack() {
        if (voiceActive) stopVoice()
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel != null && sel.isNotEmpty()) {
            ic.commitText("", 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun pressEnter() {
        if (voiceActive) stopVoice()
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        if (ei != null) {
            val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
            val noEnterAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (!noEnterAction &&
                action != EditorInfo.IME_ACTION_NONE &&
                action != EditorInfo.IME_ACTION_UNSPECIFIED
            ) {
                ic.performEditorAction(action)
                return
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    private fun switchLang() {
        if (voiceActive) stopVoice()
        lang = if (lang == "fa") "en" else "fa"
        prefs.edit().putString("lang", lang).apply()
        shift = 0
        symbols = false
        setStatus(defaultStatus())
        handler.post { renderKeys() }
    }

    private fun openSettings() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    // ---------------------------------------------------------------- voice typing

    private fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestMicPermission() {
        val i = Intent(this, PermissionActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        setStatus("اجازهٔ میکروفون را در پنجرهٔ باز شده بدهید")
    }

    private fun toggleVoice() {
        if (awaitingFinal) return
        if (voiceActive) {
            stopVoice(graceful = true)
            return
        }
        if (!hasMicPermission()) {
            requestMicPermission()
            return
        }
        startVoice()
    }

    private fun startVoice() {
        voiceActive = true
        errorStreak = 0
        updateMic()
        if (useVosk()) {
            usingVosk = true
            vosk.start()
            return
        }
        usingVosk = false
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            failVoice("سرویس تشخیص گفتار نیست؛ برنامهٔ Google را نصب/به‌روز کنید")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(listener)
        }
        setStatus("در حال آماده‌سازی…")
        listenOnce()
    }

    private fun listenOnce() {
        val tag = if (lang == "fa") "fa-IR" else "en-US"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            failVoice("خطا در شروع تشخیص گفتار")
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        handler.removeCallbacks(restartRunnable)
        handler.postDelayed(restartRunnable, delayMs)
    }

    /** Stops dictation. graceful = let the recognizer deliver the last words first. */
    private fun stopVoice(graceful: Boolean = false) {
        if (!voiceActive) return
        voiceActive = false
        handler.removeCallbacks(restartRunnable)
        updateMic()
        if (usingVosk) {
            if (graceful && vosk.isListening()) {
                awaitingFinal = true
                setStatus("در حال پایان…")
                vosk.stop()
                handler.postDelayed(finalizeRunnable, 2500)
            } else {
                vosk.cancel()
                currentInputConnection?.finishComposingText()
                setStatus(defaultStatus())
            }
            return
        }
        if (graceful) {
            awaitingFinal = true
            setStatus("در حال پایان…")
            try {
                recognizer?.stopListening()
            } catch (e: Exception) {
                // ignored, finalizeRunnable cleans up
            }
            handler.postDelayed(finalizeRunnable, 2500)
        } else {
            recognizer?.cancel()
            currentInputConnection?.finishComposingText()
            setStatus(defaultStatus())
        }
    }

    private fun failVoice(msg: String) {
        stopVoice()
        setStatus(msg)
    }

    private fun handleVoiceError(error: Int) {
        if (awaitingFinal) {
            awaitingFinal = false
            handler.removeCallbacks(finalizeRunnable)
            currentInputConnection?.finishComposingText()
            setStatus(defaultStatus())
            return
        }
        if (!voiceActive) return
        when (error) {
            SpeechRecognizer.ERROR_NO_MATCH,
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                errorStreak++
                if (errorStreak > MAX_SILENT_RESTARTS) {
                    failVoice("صدایی شنیده نشد؛ دوباره 🎤 را بزنید")
                } else {
                    scheduleRestart(200)
                }
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                errorStreak++
                recognizer?.cancel()
                if (errorStreak > MAX_SILENT_RESTARTS) {
                    failVoice("سرویس تشخیص گفتار مشغول است")
                } else {
                    scheduleRestart(500)
                }
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                stopVoice()
                requestMicPermission()
            }
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
            SpeechRecognizer.ERROR_SERVER ->
                failVoice("اینترنت لازم است (یا بستهٔ آفلاین فارسی را نصب کنید)")
            12, 13 ->
                failVoice("زبان فارسی روی سرویس تشخیص گفتار در دسترس نیست")
            else ->
                failVoice("خطای تشخیص گفتار ($error)")
        }
    }

    /** Offline engine (Persian only) is used when enabled in settings and the model is bundled. */
    private fun useVosk(): Boolean =
        lang == "fa" && prefs.getBoolean("vosk", true) && vosk.isBundled()

    private val voskCallbacks = object : VoskEngine.Callbacks {
        override fun onStatus(msg: String) {
            if (voiceActive) setStatus(msg)
        }

        override fun onPartial(text: String) {
            if (!voiceActive) return
            currentInputConnection?.setComposingText(VoskEngine.polish(text), 1)
        }

        override fun onResult(text: String, isFinal: Boolean) {
            val ic = currentInputConnection
            if (awaitingFinal) {
                if (text.isNotBlank()) {
                    ic?.commitText(VoskEngine.polish(text) + " ", 1)
                } else if (isFinal) {
                    ic?.finishComposingText()
                }
                if (isFinal) {
                    awaitingFinal = false
                    handler.removeCallbacks(finalizeRunnable)
                    setStatus(defaultStatus())
                }
                return
            }
            if (!voiceActive) return
            if (text.isNotBlank()) {
                ic?.commitText(VoskEngine.polish(text) + " ", 1)
            }
        }

        override fun onError(msg: String) {
            if (awaitingFinal) {
                awaitingFinal = false
                handler.removeCallbacks(finalizeRunnable)
                currentInputConnection?.finishComposingText()
                setStatus(defaultStatus())
                return
            }
            if (voiceActive) failVoice(msg)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            setStatus("در حال گوش دادن… بگویید")
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            val s = 1f + (rmsdB.coerceIn(0f, 10f) / 10f) * 0.25f
            micView?.scaleX = s
            micView?.scaleY = s
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            handleVoiceError(error)
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            val ic = currentInputConnection

            if (awaitingFinal) {
                awaitingFinal = false
                handler.removeCallbacks(finalizeRunnable)
                if (!text.isNullOrBlank()) ic?.commitText(text.trim() + " ", 1) else ic?.finishComposingText()
                setStatus(defaultStatus())
                return
            }
            if (!voiceActive) return

            errorStreak = 0
            if (!text.isNullOrBlank()) ic?.commitText(text.trim() + " ", 1) else ic?.finishComposingText()
            scheduleRestart(150)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (!voiceActive) return
            errorStreak = 0
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) currentInputConnection?.setComposingText(text, 1)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
