package com.example.pvkeyboard

/** Key layouts. Combining marks are written as \u escapes so they survive any editor. */
object Layouts {

    val faNumbers = listOf("۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "۰")
    val enNumbers = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

    // Standard Iranian Persian layout
    val fa: List<List<String>> = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ"),
        listOf("ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ"),
        listOf("ظ", "ط", "ز", "ر", "ذ", "د", "پ", "و")
    )

    // Persian shift layer: harakat (diacritics), brackets, hamza forms, ژ
    val faShift: List<List<String>> = listOf(
        listOf(
            "ْ", "ٌ", "ٍ", "ً", "ُ", "ِ",
            "َ", "ّ", "]", "[", "}", "{"
        ),
        listOf("ؤ", "ئ", "ي", "إ", "أ", "آ", "ة", "»", "«", ":", "؛"),
        listOf("ٓ", "ٰ", "ژ", "ٔ", "ـ", "ء", "<", ">")
    )

    val en: List<List<String>> = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )

    val symbols: List<List<String>> = listOf(
        listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
        listOf("*", "\"", "'", ":", ";", "!", "?", "،", "؛", "؟"),
        listOf("_", "=", "{", "}", "[", "]", "<", ">", "«", "»")
    )
}
