#!/usr/bin/env bash
# Downloads what offline Persian text-to-speech needs:
#   1) sherpa-onnx native libraries (pinned to the same version as the vendored Tts.kt)
#   2) the Persian Piper voice "amir" (fa_IR, medium) converted for sherpa-onnx
# Called by download_model.sh (so the existing GitHub Actions workflow picks it up automatically).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VER="v1.13.8"
MODEL="vits-piper-fa_IR-amir-medium"
ONNX="fa_IR-amir-medium.onnx"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

LIBS_URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/$VER/sherpa-onnx-$VER-android.tar.bz2"
MODEL_URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/$MODEL.tar.bz2"

# ---- 1) native libraries
echo "Downloading sherpa-onnx $VER Android libraries..."
curl -L --fail --retry 3 -o "$TMP/libs.tar.bz2" "$LIBS_URL"
mkdir -p "$TMP/libs"
tar xjf "$TMP/libs.tar.bz2" -C "$TMP/libs"

JNI="$ROOT/app/src/main/jniLibs"
rm -rf "$JNI"
for abi in arm64-v8a armeabi-v7a; do
  src="$(find "$TMP/libs" -type d -name "$abi" | head -n 1)"
  test -n "$src" || { echo "ABI folder $abi not found in the libraries archive"; exit 1; }
  mkdir -p "$JNI/$abi"
  cp "$src"/*.so "$JNI/$abi/"
done
test -f "$JNI/arm64-v8a/libsherpa-onnx-jni.so" || { echo "libsherpa-onnx-jni.so is missing"; exit 1; }
ls -lh "$JNI"/*

# ---- 2) Persian voice
fetch_release() {
  curl -L --fail --retry 3 -o "$TMP/model.tar.bz2" "$MODEL_URL" \
    && tar xjf "$TMP/model.tar.bz2" -C "$TMP" \
    && test -f "$TMP/$MODEL/$ONNX"
}

fetch_hf() {
  python3 -m venv "$TMP/venv"
  "$TMP/venv/bin/pip" install -q huggingface_hub
  "$TMP/venv/bin/python" - "$TMP/$MODEL" "$MODEL" <<'PY'
import sys
from huggingface_hub import snapshot_download
snapshot_download(repo_id="csukuangfj/" + sys.argv[2], local_dir=sys.argv[1])
PY
}

echo "Downloading Persian voice $MODEL..."
if ! fetch_release; then
  echo "GitHub release download failed, trying Hugging Face..."
  rm -rf "$TMP/$MODEL"
  fetch_hf
fi

SRC="$TMP/$MODEL"
for f in "$ONNX" tokens.txt espeak-ng-data/phontab; do
  test -e "$SRC/$f" || { echo "Unexpected voice layout, missing: $f"; exit 1; }
done

DEST="$ROOT/app/src/main/assets/tts-fa"
rm -rf "$DEST"
mkdir -p "$DEST"
cp "$SRC/$ONNX" "$SRC/tokens.txt" "$DEST/"
cp -r "$SRC/espeak-ng-data" "$DEST/"
du -sh "$DEST"
echo "Offline TTS ready."
