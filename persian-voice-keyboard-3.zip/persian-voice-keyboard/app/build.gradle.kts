plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.pvkeyboard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.pvkeyboard"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.2"

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")

    // Offline speech recognition (Vosk)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")

    // Offline Persian text-to-speech (sherpa-onnx, local AAR in app/libs)
    implementation(files("libs/sherpa-onnx.aar"))
    // Extracts the downloaded voice archive (.tar.bz2)
    implementation("org.apache.commons:commons-compress:1.26.2")
}
