package com.example.pvkeyboard

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Key press feedback: vibration and/or a short click sound, controlled from the settings screen.
 * Prefs: vib_on (Boolean), vib_ms (Int), snd_on (Boolean), snd_vol (Int 0..100)
 */
class KeyFeedback(private val ctx: Context) {

    private var vibOn = true
    private var vibMs = 20
    private var sndOn = false
    private var vol = 0.6f

    private val vibrator: Vibrator? = createVibrator()

    @Suppress("DEPRECATION")
    private fun createVibrator(): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    } catch (e: Exception) {
        null
    }

    private var pool: SoundPool? = null
    private var soundId = 0
    private var loaded = false

    fun load(p: SharedPreferences) {
        vibOn = p.getBoolean("vib_on", true)
        vibMs = p.getInt("vib_ms", 20).coerceIn(3, 100)
        sndOn = p.getBoolean("snd_on", false)
        vol = p.getInt("snd_vol", 60).coerceIn(0, 100) / 100f
        if (sndOn) ensurePool()
    }

    fun tap() {
        if (vibOn) vibrate()
        if (sndOn) click()
    }

    fun release() {
        try {
            pool?.release()
        } catch (e: Exception) {
            // ignored
        }
        pool = null
        loaded = false
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        val v = vibrator ?: return
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(vibMs.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(vibMs.toLong())
            }
        } catch (e: Exception) {
            // ignored
        }
    }

    private fun click() {
        val p = pool ?: return
        if (!loaded) return
        try {
            p.play(soundId, vol, vol, 1, 0, 1f)
        } catch (e: Exception) {
            // ignored
        }
    }

    private fun ensurePool() {
        if (pool != null) return
        try {
            val f = File(ctx.cacheDir, "key_click.wav")
            if (!f.exists() || f.length() < 100) writeWav(f)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val sp = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
            sp.setOnLoadCompleteListener { _, _, status -> loaded = (status == 0) }
            soundId = sp.load(f.absolutePath, 1)
            pool = sp
        } catch (e: Exception) {
            pool = null
        }
    }

    /** Generates a tiny 35 ms "tick" (16-bit mono PCM WAV), no audio asset needed. */
    private fun writeWav(f: File) {
        val sr = 22050
        val n = sr * 35 / 1000
        val dataLen = n * 2
        val buf = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray())
        buf.putInt(36 + dataLen)
        buf.put("WAVE".toByteArray())
        buf.put("fmt ".toByteArray())
        buf.putInt(16)
        buf.putShort(1)
        buf.putShort(1)
        buf.putInt(sr)
        buf.putInt(sr * 2)
        buf.putShort(2)
        buf.putShort(16)
        buf.put("data".toByteArray())
        buf.putInt(dataLen)
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val env = exp(-t * 140.0)
            val s = (sin(2 * PI * 1800 * t) * 0.7 + sin(2 * PI * 900 * t) * 0.3) * env
            buf.putShort((s * 30000).toInt().toShort())
        }
        f.writeBytes(buf.array())
    }
}
