package com.example.pvkeyboard

/** Key layouts. Combining marks are written as \u escapes so they survive any editor. */
object Layouts {

    val faNumbers = listOf("۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "۰")
    val enNumbers = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

    // Standard Iranian Persian layout
    val fa: List<List<String>> = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ"),
        listOf("ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ"),
        listOf("ظ", "ط", "ز", "ر", "ذ", "د", "پ", "و")
    )

    // Persian shift layer: harakat (diacritics), brackets, hamza forms, ژ
    val faShift: List<List<String>> = listOf(
        listOf(
            "ْ", "ٌ", "ٍ", "ً", "ُ", "ِ",
            "َ", "ّ", "]", "[", "}", "{"
        ),
        listOf("ؤ", "ئ", "ي", "إ", "أ", "آ", "ة", "»", "«", ":", "؛"),
        listOf("ٓ", "ٰ", "ژ", "ٔ", "ـ", "ء", "<", ">")
    )

    val en: List<List<String>> = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("z", "x", "c", "v", "b", "n", "m")
    )

    // Long-press alternates (like Gboard). The first one is shown as a small hint on the key.
    val faAlts: Map<String, List<String>> = mapOf(
        "ا" to listOf("آ", "ء", "أ", "إ"),
        "ز" to listOf("ژ"),
        "و" to listOf("ؤ"),
        "ی" to listOf("ئ", "ي"),
        "ه" to listOf("ة", "ۀ"),
        "ک" to listOf("ك"),
        "،" to listOf("؛", ":", "!", "؟"),
        "." to listOf("…", "؟", "!", "?")
    )

    val enAlts: Map<String, List<String>> = mapOf(
        "a" to listOf("à", "á", "â", "ä", "æ", "ã", "å"),
        "e" to listOf("è", "é", "ê", "ë"),
        "i" to listOf("ì", "í", "î", "ï"),
        "o" to listOf("ò", "ó", "ô", "ö", "õ", "ø", "œ"),
        "u" to listOf("ù", "ú", "û", "ü"),
        "c" to listOf("ç"),
        "n" to listOf("ñ"),
        "s" to listOf("ß"),
        "y" to listOf("ý", "ÿ"),
        "," to listOf(";", ":", "!", "?"),
        "." to listOf("…", "?", "!", ",")
    )

    val symbols: List<List<String>> = listOf(
        listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
        listOf("*", "\"", "'", ":", ";", "!", "?", "،", "؛", "؟"),
        listOf("_", "=", "{", "}", "[", "]", "<", ">", "«", "»")
    )
}
