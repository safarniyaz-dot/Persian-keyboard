package com.example.pvkeyboard

import android.content.SharedPreferences
import android.view.inputmethod.InputConnection

/**
 * Spoken editing commands for Persian dictation.
 *   "تش"  -> delete the last typed word (say it again to delete another word)
 *   "ویر" -> insert a comma (،)
 *   "نقط" -> insert a period (.)
 * The trigger words can be changed in the app settings (several words separated by comma).
 */
object VoiceCommands {

    const val DEF_DEL = "تش"
    const val DEF_COMMA = "ویر"
    const val DEF_PERIOD = "نقط"

    class Words(val del: Set<String>, val comma: Set<String>, val period: Set<String>)

    fun defaults(): Words = Words(parse(DEF_DEL), parse(DEF_COMMA), parse(DEF_PERIOD))

    fun load(p: SharedPreferences): Words = Words(
        parse(p.getString("cmd_del", DEF_DEL) ?: DEF_DEL),
        parse(p.getString("cmd_comma", DEF_COMMA) ?: DEF_COMMA),
        parse(p.getString("cmd_period", DEF_PERIOD) ?: DEF_PERIOD)
    )

    private val splitter = Regex("[,،;؛\\s]+")
    private val spaces = Regex("\\s+")
    private val spaceBeforePunct = Regex(" +([،.])")
    private const val PUNCT = "،؛؟.,:;!?…«»()[]{}\"'"

    private fun norm(s: String): String =
        s.replace('ي', 'ی').replace('ك', 'ک')
            .replace("‌", "").replace("‏", "").replace("‎", "")
            .trim()

    private fun parse(s: String): Set<String> =
        s.split(splitter).map { norm(it) }.filter { it.isNotEmpty() }.toSet()

    /** Text to show while the user is still speaking (commands are previewed, nothing is deleted yet). */
    fun preview(raw: String, w: Words, polish: (String) -> String): String {
        val out = ArrayList<String>()
        for (tok in raw.trim().split(spaces)) {
            if (tok.isEmpty()) continue
            val n = norm(tok)
            when {
                n in w.del -> {}
                n in w.comma -> out.add("،")
                n in w.period -> out.add(".")
                else -> out.add(tok)
            }
        }
        return polish(out.joinToString(" ")).replace(spaceBeforePunct, "$1")
    }

    /**
     * Types the recognized text into the field and executes the commands in it, in order.
     * hadComposing = the partial text of this utterance is currently shown as composing text.
     */
    fun apply(
        ic: InputConnection,
        text: String,
        w: Words,
        hadComposing: Boolean,
        polish: (String) -> String
    ) {
        ic.beginBatchEdit()
        try {
            if (hadComposing) ic.setComposingText("", 1)
            ic.finishComposingText()

            val buf = ArrayList<String>()
            fun flush() {
                if (buf.isNotEmpty()) {
                    ic.commitText(polish(buf.joinToString(" ")) + " ", 1)
                    buf.clear()
                }
            }
            for (tok in text.trim().split(spaces)) {
                if (tok.isEmpty()) continue
                val n = norm(tok)
                when {
                    n in w.del -> {
                        flush()
                        deleteLastWord(ic)
                    }
                    n in w.comma -> {
                        flush()
                        putPunct(ic, "،")
                    }
                    n in w.period -> {
                        flush()
                        putPunct(ic, ".")
                    }
                    else -> buf.add(tok)
                }
            }
            flush()
        } finally {
            ic.endBatchEdit()
        }
    }

    private fun isSpace(c: Char) = c == ' ' || c == ' '

    private fun isPunct(c: Char) = PUNCT.indexOf(c) >= 0

    /** Removes trailing spaces, then writes the punctuation mark followed by one space. */
    private fun putPunct(ic: InputConnection, p: String) {
        val before = ic.getTextBeforeCursor(20, 0)?.toString() ?: ""
        var n = 0
        while (n < before.length && isSpace(before[before.length - 1 - n])) n++
        if (n > 0) ic.deleteSurroundingText(n, 0)
        ic.commitText("$p ", 1)
    }

    /**
     * Deletes the last typed word (and the spaces after it). If the text ends with punctuation,
     * only that punctuation is removed first. Repeating the command keeps going backwards.
     */
    private fun deleteLastWord(ic: InputConnection) {
        val before = ic.getTextBeforeCursor(200, 0)?.toString() ?: return
        if (before.isEmpty()) return

        var i = before.length
        while (i > 0 && isSpace(before[i - 1])) i--
        if (i == 0) {
            ic.deleteSurroundingText(before.length, 0)
            return
        }
        if (before[i - 1] == '\n') {
            ic.deleteSurroundingText(before.length - i + 1, 0)
            return
        }

        var j = i
        if (isPunct(before[i - 1])) {
            while (j > 0 && isPunct(before[j - 1])) j--
            ic.deleteSurroundingText(before.length - j, 0)
            if (j > 0 && !before[j - 1].isWhitespace()) ic.commitText(" ", 1)
            return
        }
        while (j > 0 && !before[j - 1].isWhitespace() && !isPunct(before[j - 1])) j--
        ic.deleteSurroundingText(before.length - j, 0)
    }
}
