package com.example.pvkeyboard

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import java.io.IOException

/**
 * Fully offline Persian speech recognition (Vosk, Kaldi based).
 * The model lives in assets/model-fa (downloaded at build time by scripts/download_model.sh)
 * and is unpacked to app storage on first use.
 */
class VoskEngine(private val context: Context, private val cb: Callbacks) {

    interface Callbacks {
        fun onStatus(msg: String)
        fun onPartial(text: String)
        /** isFinal = true when it is the last result after stop(). */
        fun onResult(text: String, isFinal: Boolean)
        fun onError(msg: String)
    }

    companion object {
        const val ASSET_DIR = "model-fa"
        private const val SAMPLE_RATE = 16000.0f

        private val prefixRegex = Regex("(?<![؀-ۿ])(ن?می) (?=[؀-ۿ])")
        private val suffixRegex = Regex(" (ها|های|هایی|هایم|هایت|هایش|ترین)(?![؀-ۿ])")

        /** Vosk returns plain words; join common prefixes/suffixes with a half-space (ZWNJ). */
        fun polish(s: String): String =
            s.replace(prefixRegex, "$1‌").replace(suffixRegex, "‌$1")
    }

    private var model: Model? = null
    private var service: SpeechService? = null
    private var loading = false
    private var wanted = false

    private val bundled: Boolean by lazy {
        try {
            (context.assets.list(ASSET_DIR)?.size ?: 0) > 0
        } catch (e: IOException) {
            false
        }
    }

    fun isBundled(): Boolean = bundled

    fun isListening(): Boolean = service != null

    fun start() {
        wanted = true
        val m = model
        if (m != null) {
            listen(m)
            return
        }
        if (loading) return
        loading = true
        cb.onStatus("در حال آماده‌سازی مدل آفلاین (فقط بار اول، چند ثانیه)…")
        StorageService.unpack(
            context, ASSET_DIR, "model",
            { loaded: Model ->
                loading = false
                model = loaded
                if (wanted) listen(loaded)
            },
            { e: IOException ->
                loading = false
                wanted = false
                cb.onError("بارگذاری مدل آفلاین ناموفق بود: ${e.message ?: ""}")
            }
        )
    }

    private fun listen(m: Model) {
        try {
            shutdownService()
            val rec = Recognizer(m, SAMPLE_RATE)
            val s = SpeechService(rec, SAMPLE_RATE)
            service = s
            s.startListening(listener)
            cb.onStatus("آفلاین • در حال گوش دادن… بگویید")
        } catch (e: Exception) {
            service = null
            cb.onError("میکروفون در دسترس نیست")
        }
    }

    /** Stop and deliver the remaining words through onResult(isFinal = true). */
    fun stop() {
        wanted = false
        val s = service ?: return
        try {
            s.stop()
        } catch (e: Exception) {
            // ignored
        }
        shutdownService()
    }

    /** Stop immediately, no more results. */
    fun cancel() {
        wanted = false
        try {
            service?.cancel()
        } catch (e: Exception) {
            // ignored
        }
        shutdownService()
    }

    fun release() {
        cancel()
        try {
            model?.close()
        } catch (e: Exception) {
            // ignored
        }
        model = null
    }

    private fun shutdownService() {
        try {
            service?.shutdown()
        } catch (e: Exception) {
            // ignored
        }
        service = null
    }

    private fun field(h: String?, key: String): String =
        try {
            if (h == null) "" else JSONObject(h).optString(key, "").trim()
        } catch (e: Exception) {
            ""
        }

    private val listener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) {
            val t = field(hypothesis, "partial")
            if (t.isNotEmpty()) cb.onPartial(t)
        }

        override fun onResult(hypothesis: String?) {
            cb.onResult(field(hypothesis, "text"), false)
        }

        override fun onFinalResult(hypothesis: String?) {
            cb.onResult(field(hypothesis, "text"), true)
        }

        override fun onError(exception: Exception?) {
            cb.onError("خطای تشخیص آفلاین: ${exception?.message ?: ""}")
        }

        override fun onTimeout() {}
    }
}
