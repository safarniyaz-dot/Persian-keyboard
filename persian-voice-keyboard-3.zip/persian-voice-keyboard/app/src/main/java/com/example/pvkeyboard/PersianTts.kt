package com.example.pvkeyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Offline Persian text-to-speech using sherpa-onnx with a Piper VITS voice.
 *
 * The voice (~21 MB) is NOT in the APK. It is downloaded once, after install,
 * by [installVoice] and stored in filesDir. Playback is fully offline afterwards.
 */
class PersianTts(context: Context, private val onState: (Boolean) -> Unit = {}) {

    companion object {
        private const val VOICE_URL =
            "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-fa_IR-gyro-medium-int8.tar.bz2"
        private const val VOICE_DIR = "tts-fa"
        private const val READY_FILE = "ready.txt"   // holds the absolute path of the voice folder
        /** Characters per generated piece; keeps latency low and memory small. */
        private const val MAX_CHUNK = 300
        private val sentenceEnd = Regex("(?<=[.!?؟!…\\n])\\s+")
    }

    private val appContext = context.applicationContext
    private val root = File(appContext.filesDir, VOICE_DIR)
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var engine: OfflineTts? = null
    @Volatile private var generation = 0
    @Volatile private var track: AudioTrack? = null
    @Volatile private var speaking = false

    init {
        if (isInstalled()) worker.execute { loadEngine() }
    }

    /** True if the voice has been downloaded and unpacked. */
    fun isInstalled(): Boolean = voiceDir() != null

    /** True once the voice is loaded and ready to speak. */
    fun isAvailable(): Boolean = engine != null

    fun isSpeaking(): Boolean = speaking

    /**
     * Downloads and unpacks the voice (if needed), then loads it.
     * [onProgress] receives 0..100 on the main thread; [onDone] receives success on the main thread.
     */
    fun installVoice(onProgress: (Int) -> Unit, onDone: (Boolean) -> Unit) {
        worker.execute {
            val ok = try {
                if (!isInstalled()) download(onProgress)
                loadEngine()
                true
            } catch (e: Throwable) {
                false
            }
            main.post { onDone(ok) }
        }
    }

    /** Reads [text] aloud. Returns false if the voice is not loaded or the text is empty. */
    fun speak(text: String): Boolean {
        if (engine == null) return false
        val clean = text.replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return false

        stop()
        val gen = ++generation
        val pieces = chunks(clean)
        setSpeaking(true)
        worker.execute {
            try {
                for (piece in pieces) {
                    if (gen != generation) break
                    val tts = engine ?: break
                    val audio = tts.generate(text = piece, sid = 0, speed = 1.0f)
                    if (gen != generation) break
                    play(audio.samples, audio.sampleRate, gen)
                }
            } catch (e: Throwable) {
                // generation or playback failed; reset state below
            } finally {
                releaseTrack()
                if (gen == generation) setSpeaking(false)
            }
        }
        return true
    }

    /** Stops playback and cancels any pending pieces. */
    fun stop() {
        generation++
        try {
            track?.pause()
            track?.flush()
        } catch (e: Exception) {
            // ignored
        }
        setSpeaking(false)
    }

    fun shutdown() {
        stop()
        worker.execute {
            releaseTrack()
            engine?.release()
            engine = null
        }
        worker.shutdown()
    }

    // ------------------------------------------------------------ voice install

    /** Returns the voice folder if it is fully installed, else null. */
    private fun voiceDir(): File? {
        val ready = File(root, READY_FILE)
        if (!ready.exists()) return null
        val dir = File(ready.readText().trim())
        return if (File(dir, "tokens.txt").exists()) dir else null
    }

    private fun download(onProgress: (Int) -> Unit) {
        root.deleteRecursively()
        root.mkdirs()
        val archive = File(appContext.cacheDir, "tts-fa.tar.bz2")

        val conn = URL(VOICE_URL).openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.connect()
        if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            FileOutputStream(archive).use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var last = -1
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != last) { last = pct; main.post { onProgress(pct) } }
                    }
                }
            }
        }
        conn.disconnect()

        var topDir: String? = null
        BZip2CompressorInputStream(BufferedInputStream(archive.inputStream())).use { bz ->
            TarArchiveInputStream(bz).use { tar ->
                var entry = tar.nextTarEntry
                while (entry != null) {
                    if (topDir == null) topDir = entry.name.substringBefore('/')
                    val out = File(root, entry.name)
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { tar.copyTo(it) }
                    }
                    entry = tar.nextTarEntry
                }
            }
        }
        archive.delete()

        val dir = File(root, topDir ?: throw IllegalStateException("empty archive"))
        if (!File(dir, "tokens.txt").exists()) throw IllegalStateException("unexpected layout")
        File(root, READY_FILE).writeText(dir.absolutePath)
        main.post { onProgress(100) }
    }

    private fun loadEngine() {
        if (engine != null) return
        val dir = voiceDir() ?: return
        val onnx = dir.listFiles { f -> f.name.endsWith(".onnx") }?.firstOrNull() ?: return
        val vits = OfflineTtsVitsModelConfig(
            model = onnx.absolutePath,
            tokens = File(dir, "tokens.txt").absolutePath,
            dataDir = File(dir, "espeak-ng-data").absolutePath,
            lexicon = "",
            dictDir = "",
            noiseScale = 0.667f,
            noiseScaleW = 0.8f,
            lengthScale = 1.0f,
        )
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                vits = vits,
                numThreads = 2,
                debug = false,
                provider = "cpu",
            ),
            maxNumSentences = 1,
        )
        engine = OfflineTts(null, config)
    }

    // ------------------------------------------------------------ playback

    private fun play(samples: FloatArray, sampleRate: Int, gen: Int) {
        val t = track ?: createTrack(sampleRate).also { track = it }
        t.play()
        var offset = 0
        val block = 4096
        while (offset < samples.size && gen == generation) {
            val n = minOf(block, samples.size - offset)
            val written = t.write(samples, offset, n, AudioTrack.WRITE_BLOCKING)
            if (written <= 0) break
            offset += written
        }
    }

    private fun createTrack(sampleRate: Int): AudioTrack {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT
        )
        return AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                .build(),
            maxOf(minBuf, sampleRate * 2),
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
    }

    private fun releaseTrack() {
        val t = track ?: return
        track = null
        try {
            t.pause()
            t.flush()
            t.release()
        } catch (e: Exception) {
            // ignored
        }
    }

    private fun setSpeaking(value: Boolean) {
        speaking = value
        main.post { onState(value) }
    }

    /** Splits text at sentence ends so every piece is under [MAX_CHUNK] characters. */
    private fun chunks(s: String): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        for (sentence in s.split(sentenceEnd)) {
            var rest = sentence
            while (rest.length > MAX_CHUNK) {
                if (cur.isNotEmpty()) { out.add(cur.toString()); cur.clear() }
                out.add(rest.substring(0, MAX_CHUNK))
                rest = rest.substring(MAX_CHUNK)
            }
            if (cur.length + rest.length + 1 > MAX_CHUNK && cur.isNotEmpty()) {
                out.add(cur.toString())
                cur.clear()
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(rest)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }
}
