#!/usr/bin/env bash
# Downloads the small Persian Vosk model into app/src/main/assets/model-fa
# Used by the GitHub Actions workflow; run it once yourself before building locally.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/app/src/main/assets/model-fa"
TMP="$(mktemp -d)"

URL1="https://alphacephei.com/vosk/models/vosk-model-small-fa-0.5.zip"
URL2="https://huggingface.co/rhasspy/vosk-models/resolve/main/fa/vosk-model-small-fa-0.5.zip"

echo "Downloading Persian model..."
curl -L --fail --retry 3 -o "$TMP/fa.zip" "$URL1" || curl -L --fail --retry 3 -o "$TMP/fa.zip" "$URL2"

unzip -q "$TMP/fa.zip" -d "$TMP/unz"
SRC="$(find "$TMP/unz" -mindepth 1 -maxdepth 1 -type d | head -n 1)"
test -d "$SRC/am" || { echo "Unexpected model layout"; exit 1; }

rm -rf "$DEST"
mkdir -p "$(dirname "$DEST")"
mv "$SRC" "$DEST"
# StorageService.unpack needs a 'uuid' file to know when to re-copy the model
cat /proc/sys/kernel/random/uuid > "$DEST/uuid" 2>/dev/null || date +%s > "$DEST/uuid"

rm -rf "$TMP"
du -sh "$DEST"
echo "Model ready in $DEST"
